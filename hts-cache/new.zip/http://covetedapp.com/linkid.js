<!DOCTYPE html>
<html lang="en-US" prefix="og: http://ogp.me/ns#">
<head>
    <meta sidebar-type="" name="post-id" content="" setting-status="general" detail="other" page-url="" />	<meta charset="UTF-8" />
	<meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1" />
    <meta name="format-detection" content="telephone=no">



	<link rel="pingback" href="http://covetedapp.com/xmlrpc.php" />

	<!-- Theme Hook -->
    <title>Page not found &ndash; Coveted | Dating app</title>

<!-- This site is optimized with the Yoast SEO plugin v5.8 - https://yoast.com/wordpress/plugins/seo/ -->
<meta name="robots" content="noindex,follow"/>
<meta property="og:locale" content="en_US" />
<meta property="og:type" content="object" />
<meta property="og:title" content="Page not found &ndash; Coveted | Dating app" />
<meta property="og:site_name" content="Coveted | Dating app" />
<meta name="twitter:card" content="summary_large_image" />
<meta name="twitter:title" content="Page not found &ndash; Coveted | Dating app" />
<meta name="twitter:site" content="@covetedapp" />
<script type='application/ld+json'>{"@context":"http:\/\/schema.org","@type":"WebSite","@id":"#website","url":"http:\/\/covetedapp.com\/","name":"Coveted | A new dating experience","potentialAction":{"@type":"SearchAction","target":"http:\/\/covetedapp.com\/?s={search_term_string}","query-input":"required name=search_term_string"}}</script>
<script type='application/ld+json'>{"@context":"http:\/\/schema.org","@type":"Organization","url":false,"sameAs":["http:\/\/facebook.com\/covetedapp","http:\/\/instagram.com\/covetedapp","https:\/\/twitter.com\/covetedapp"],"@id":"#organization","name":"Coveted","logo":"http:\/\/covetedapp.com\/wp-content\/uploads\/2017\/11\/DarkFinal1.png"}</script>
<!-- / Yoast SEO plugin. -->

<link rel='dns-prefetch' href='//cdnjs.cloudflare.com' />
<link rel='dns-prefetch' href='//s.w.org' />
<link rel="alternate" type="application/rss+xml" title="Coveted | Dating app &raquo; Feed" href="http://covetedapp.com/feed/" />
<link rel="alternate" type="application/rss+xml" title="Coveted | Dating app &raquo; Comments Feed" href="http://covetedapp.com/comments/feed/" />
<!-- This site uses the Google Analytics by MonsterInsights plugin v6.2.6 - Using Analytics tracking - https://www.monsterinsights.com/ -->
<script type="text/javascript" data-cfasync="false">
		var disableStr = 'ga-disable-UA-109500590-1';

	/* Function to detect opted out users */
	function __gaTrackerIsOptedOut() {
		return document.cookie.indexOf(disableStr + '=true') > -1;
	}

	/* Disable tracking if the opt-out cookie exists. */
	if ( __gaTrackerIsOptedOut() ) {
		window[disableStr] = true;
	}

	/* Opt-out function */
	function __gaTrackerOptout() {
	  document.cookie = disableStr + '=true; expires=Thu, 31 Dec 2099 23:59:59 UTC; path=/';
	  window[disableStr] = true;
	}
		(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
		(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
		m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
	})(window,document,'script','//www.google-analytics.com/analytics.js','__gaTracker');

	__gaTracker('create', 'UA-109500590-1', 'auto');
	__gaTracker('set', 'forceSSL', true);
	__gaTracker('require', 'displayfeatures');
	__gaTracker('require', 'linkid', 'linkid.js');
	__gaTracker('send','pageview','/404.html?page=' + document.location.pathname + document.location.search + '&from=' + document.referrer);
</script>
<!-- / Google Analytics by MonsterInsights -->
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/2.3\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/2.3\/svg\/","svgExt":".svg","source":{"concatemoji":"http:\/\/covetedapp.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=4.9.1"}};
			!function(a,b,c){function d(a,b){var c=String.fromCharCode;l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,a),0,0);var d=k.toDataURL();l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,b),0,0);var e=k.toDataURL();return d===e}function e(a){var b;if(!l||!l.fillText)return!1;switch(l.textBaseline="top",l.font="600 32px Arial",a){case"flag":return!(b=d([55356,56826,55356,56819],[55356,56826,8203,55356,56819]))&&(b=d([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]),!b);case"emoji":return b=d([55358,56794,8205,9794,65039],[55358,56794,8203,9794,65039]),!b}return!1}function f(a){var c=b.createElement("script");c.src=a,c.defer=c.type="text/javascript",b.getElementsByTagName("head")[0].appendChild(c)}var g,h,i,j,k=b.createElement("canvas"),l=k.getContext&&k.getContext("2d");for(j=Array("flag","emoji"),c.supports={everything:!0,everythingExceptFlag:!0},i=0;i<j.length;i++)c.supports[j[i]]=e(j[i]),c.supports.everything=c.supports.everything&&c.supports[j[i]],"flag"!==j[i]&&(c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&c.supports[j[i]]);c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&!c.supports.flag,c.DOMReady=!1,c.readyCallback=function(){c.DOMReady=!0},c.supports.everything||(h=function(){c.readyCallback()},b.addEventListener?(b.addEventListener("DOMContentLoaded",h,!1),a.addEventListener("load",h,!1)):(a.attachEvent("onload",h),b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&c.readyCallback()})),g=c.source||{},g.concatemoji?f(g.concatemoji):g.wpemoji&&g.twemoji&&(f(g.twemoji),f(g.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
<link rel='stylesheet' id='contact-form-7-css'  href='http://covetedapp.com/wp-content/plugins/contact-form-7/includes/css/styles.css?ver=4.9.1' type='text/css' media='all' />
<link rel='stylesheet' id='go-pricing-styles-css'  href='http://covetedapp.com/wp-content/plugins/go_pricing/assets/css/go_pricing_styles.css?ver=3.3.8' type='text/css' media='all' />
<link rel='stylesheet' id='rs-plugin-settings-css'  href='http://covetedapp.com/wp-content/plugins/revslider/public/assets/css/settings.css?ver=5.4.6.3' type='text/css' media='all' />
<style id='rs-plugin-settings-inline-css' type='text/css'>
#rs-demo-id {}
</style>
<link rel='stylesheet' id='woocommerce-layout-css'  href='http://covetedapp.com/wp-content/plugins/woocommerce/assets/css/woocommerce-layout.css?ver=3.2.4' type='text/css' media='all' />
<link rel='stylesheet' id='woocommerce-smallscreen-css'  href='http://covetedapp.com/wp-content/plugins/woocommerce/assets/css/woocommerce-smallscreen.css?ver=3.2.4' type='text/css' media='only screen and (max-width: 768px)' />
<link rel='stylesheet' id='woocommerce-general-css'  href='http://covetedapp.com/wp-content/plugins/woocommerce/assets/css/woocommerce.css?ver=3.2.4' type='text/css' media='all' />
<link rel='stylesheet' id='style-css'  href='http://covetedapp.com/wp-content/themes/massive-dynamic/style.css?ver=5.3' type='text/css' media='all' />
<link rel='stylesheet' id='page-style-css'  href='http://covetedapp.com/wp-content/uploads/md_cache/.css?ver=5.3' type='text/css' media='all' />
<link rel='stylesheet' id='plugin-styles-css'  href='http://covetedapp.com/wp-content/themes/massive-dynamic/assets/css/plugin.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='woo-commerce-styles-css'  href='http://covetedapp.com/wp-content/themes/massive-dynamic/assets/css/woo-commerce.min.css?ver=5.3' type='text/css' media='all' />
<link rel='stylesheet' id='px-iconfonts-style-css'  href='http://covetedapp.com/wp-content/themes/massive-dynamic/assets/css/iconfonts.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='flexslider-style-css'  href='http://covetedapp.com/wp-content/themes/massive-dynamic/assets/css/flexslider.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='responsive-style-css'  href='http://covetedapp.com/wp-content/themes/massive-dynamic/assets/css/responsive.min.css?ver=5.3' type='text/css' media='all' />
<style id='responsive-style-inline-css' type='text/css'>
h1{color:rgb(0,0,0);font-family:Poppins;font-weight:400;font-style:normal;font-size:70px;line-height:75px;letter-spacing:0px;}h2{color:rgb(0,0,0);font-family:Poppins;font-weight:400;font-style:normal;font-size:60px;line-height:65px;letter-spacing:0px;}h3, h3.wpb_accordion_header,h3.wpb_toggle_header,.woocommerce-loop-product__title{color:rgb(0,0,0);font-family:Poppins;font-weight:400;font-style:normal;font-size:50px;line-height:55px;letter-spacing:0px;}h4{color:rgb(0,0,0);font-family:Poppins;font-weight:400;font-style:normal;font-size:40px;line-height:45px;letter-spacing:0px;}h5{color:rgb(0,0,0);font-family:Poppins;font-weight:400;font-style:normal;font-size:30px;line-height:35px;letter-spacing:0px;}h6{color:rgb(0,0,0);font-family:Poppins;font-weight:400;font-style:;font-size:18px;line-height:30px;letter-spacing:0px;}p{color:rgb(0,0,0);font-family:Work Sans;font-weight:400;font-style:normal;font-size:14px;line-height:14px;letter-spacing:0px;}a{color:rgb(0,0,0);font-family:Work Sans;font-weight:400;font-style:normal;font-size:14px;line-height:14px;letter-spacing:0px;}.layout{padding-top:0px;padding-bottom:0px;width:100%;}main{padding-top:0px;}header .content ul.icons-pack li.icon ,header.top-block .style-style2 .icons-pack .icon.notification-item{display:none;}header { top:22px;}header[class *= "side-" ]{width: 14%;;}header:not(.top-block) .top nav > ul > li .menu-title .icon , header.side-classic .side nav > ul > li > a .menu-title .icon, header.side-classic.standard-mode .style-center nav > ul > li > a .menu-title .icon, .gather-overlay .navigation li a span.icon, header.top-block.header-style1 .navigation > ul > li > a span.icon, header:not(.top-block) .top nav > ul > li .hover-effect .icon {display:none;} header:not(.top-block) .top nav > ul > li .menu-title .title, header.side-classic .side nav > ul > li > a .menu-title .title, header:not(.top-block) .top nav > ul > li .hover-effect .title {display:inline-block;}.activeMenu{ color:rgb(255,255,255) !important;}header a, header .navigation a, header .navigation, .gather-overlay .menu a, header.side-classic div.footer .footer-content .copyright p{ color:rgb(255,255,255);font-family:Poppins;font-weight:400;font-style:normal;font-size:14px;letter-spacing:0px;line-height : 1.5em;}header .icons-pack a{color:rgb(255,255,255)}header .navigation .separator a {background-color:rgba(255,255,255,0.5);;}header .icons-pack .elem-container .title-content{color:rgb(255,255,255);}.top-classic .navigation .menu-separator,.top-logotop .navigation .menu-separator{ background-color:rgb(255,255,255);}.top-classic:not(.header-clone) .style-wireframe .navigation .menu-separator{ background-color:rgb(255,255,255);}header.top-block .icons-pack li .elem-container,header .top .icons-pack .icon span,header.top-block .icons-pack li .title-content .icon,header.top-modern .icons-pack li .title-content .icon,header .icons-pack a{ font-size:18px;}.gather-btn .gather-menu-icon,header .icons-pack a.shopcart .icon-shopcart2,header .icons-pack a.shopcart .icon-shopping-cart{font-size:21px;}header .icons-pack .shopcart-item .number{color:rgb(255,255,255);background-color:rgb(255,255,255);}.layout-container .business{display:none;}header.top-classic:not(.header-clone) .content:not(.style-wireframe) nav > ul > li:hover > a .menu-title , header.top-classic:not(.header-clone) .content:not(.style-wireframe) nav > ul > li:hover > a .menu-title:after{ color:rgb(255,255,255);} .top-classic .style-wireframe .navigation > ul > li:hover .menu-separator{ background-color:rgb(255,255,255);} header.top-classic .icons-pack .icon:hover { color:rgb(255,255,255);}header.top-modern .btn-1b:after { background:rgb(255,255,255);}header.top-modern .btn-1b:active{ background:rgb(255,255,255);}header.top-modern nav > ul> li, header.top-modern .icons-pack li, header.top-modern .first-part{ border-right: 1px solid rgba(255,255,255,0.3);;}header.top-modern .business{ border-bottom: 1px solid rgba(255,255,255,0.3);;}header.top-modern .business, header.top-modern .business a{ color:rgb(255,255,255);}header.side-classic nav > ul > li:hover > a, header.side-classic.standard-mode .icons-holder ul.icons-pack li:hover a, header.side-classic.standard-mode .footer-socials li:hover a, header.side-classic nav > ul > li.has-dropdown:not(.megamenu):hover > a, header.side-classic nav > ul > li:hover > a > .menu-title span, header.side-classic .footer-socials li a .hover, header.side-classic .icons-pack li a .hover, header.side-modern .icons-pack li a span.hover, header.side-modern .nav-modern-button span.hover, header.side-modern .footer-socials span.hover, header.side-classic nav > ul > li.has-dropdown:not(.megamenu) .dropdown a:hover .menu-title span, header.side-classic nav > ul > li > ul li.has-dropdown:not(.megamenu):hover > a .menu-title span{ color:rgb(255,255,255);border-color:rgb(255,255,255);}header.side-classic div.footer ul li.info .footer-content span, header.side-classic .icons-pack li.search .search-form input{ color:rgb(255,255,255);}header.side-classic div.footer ul, header.side-classic div.footer ul li, header.side-classic .icons-holder{ border-color:rgb(255,255,255);}header.side-classic .icons-holder li hr{ background-color:rgb(255,255,255);}header .side .footer .copyright p{ color:rgb(255,255,255);}header .color-overlay, header.side-modern .footer .info .footer-content .copyright, header.side-modern .footer .info .footer-content .footer-socials, header.side-modern .search-form input[type="text"]{background-color: rgba(255,255,255,0);}header:not(.header-clone) > .color-overlay{}.second-header-bg {}header nav.navigation li.megamenu > .dropdown, header nav.navigation li.has-dropdown > .dropdown{ display : table; position: absolute; top:70px;}header nav.navigation li.megamenu > .dropdown > .megamenu-dropdown-overlay, .gather-overlay nav li.megamenu > .dropdown > .megamenu-dropdown-overlay, header nav > ul > li.has-dropdown:not(.megamenu) ul .megamenu-dropdown-overlay{ background-color:rgba(255,255,255,.8);}header nav.navigation > ul > li.megamenu > ul > li > a{ color:rgb(200,200,200);}header[class *= "top-"]:not(.right) nav.navigation li.megamenu > ul.dropdown:not(.side-line), header[class *= "top-"]:not(.right) nav.navigation > ul > li.has-dropdown > ul.dropdown:not(.side-line){border-top:3px solid rgba(63,63,63,1);}header.top nav.navigation > ul > li.has-dropdown:not(.megamenu) .dropdown.side-line, header.top nav.navigation li.megamenu > .dropdown.side-line, .gather-overlay nav.navigation > ul > li.has-dropdown:not(.megamenu) .dropdown.side-line, .gather-overlay nav.navigation li.megamenu > .dropdown.side-line{ border-left: 3px solid rgba(63,63,63,1);}header.top nav.navigation > ul > li.has-dropdown:not(.megamenu) .dropdown.side-line li:after, .gather-overlay nav.navigation > ul > li.has-dropdown:not(.megamenu) .dropdown.side-line li:after{ background-color:rgba(0,0,0,0.3);;}header[class *= "top-"]:not(.right) nav.navigation li.megamenu > .dropdown,header[class *= "top-"]:not(.right) nav.navigation li.has-dropdown > .dropdown{left: 0;}header[class *= "top-"] nav .dropdown a, header[class *= "side-"] nav .dropdown a, .gather-overlay nav .dropdown a{ font-size:13px;}.gather-overlay nav.navigation li.megamenu > .dropdown, .gather-overlay nav.navigation li.has-dropdown > .dropdown{ background-color:rgba(255,255,255,.8);display : table; left: 0; position: absolute; top: 150%; }header.left nav.navigation > ul > li.has-dropdown > .dropdown .megamenu-dropdown-overlay, header.side-modern .side.style-style2 nav > ul > li .megamenu-dropdown-overlay, header.side-modern .side.style-style1 nav > ul .megamenu-dropdown-overlay, header.side-modern .style-style1.side nav ul li{ background-color:rgba(255,255,255,.8);}header.side-modern .style-style1.side nav ul li, header.side-modern .style-style1.side nav.navigation > ul > li.has-dropdown .dropdown{ border-color:rgba(0,0,0,0.3);;color:rgb(0,0,0);}header nav.navigation .dropdown a, header.side-modern nav.navigation a, .gather-overlay nav.navigation .dropdown a{ color:rgb(0,0,0);position: relative !important; width: auto !important;}header .top nav > ul > li > ul li:hover > a .menu-title span, header .top nav > ul > li .dropdown a:hover .menu-title span, .gather-overlay nav > ul > li > ul li:hover > a .menu-title span, .gather-overlay nav > ul > li .dropdown a:hover .menu-title span, header.side-classic nav > ul > li > ul li:hover > a .menu-title span, header.side-classic nav > ul > li .dropdown a:hover .menu-title span, header.side-modern .side.style-style2 nav.navigation ul li a:hover{ color:rgba(63,63,63,1);border-color:rgba(63,63,63,1);}header.side-modern .side.style-style1 nav.navigation ul li:hover{ background-color:rgba(63,63,63,1);}.layout-container> .color-overlay,.layout-container> .texture-overlay,.layout-container > .bg-image { display:none; }.layout-container > .color-overlay.image-type,.layout-container> .bg-image { display:none; }.layout-container > .color-overlay.texture-type,.layout-container> .texture-overlay{ display:none; }.layout-container> .color-overlay.color-type {background-color:#FFF;}.layout-container> .bg-image { background-repeat:no-repeat;background-attachment:fixed;background-position:center top;background-size: cover;opacity:1;}.layout-container> .texture-overlay { opacity:0.5;background-image: url(http://covetedapp.com/wp-content/themes/massive-dynamic/lib/customizer/assets/images/texture/1.png);}footer> .color-overlay,footer> .texture-overlay,footer > .bg-image { display:none; }footer> .color-overlay.color-type { display:none; }footer > .color-overlay.texture-type,footer> .texture-overlay{ display:none; }footer> .bg-image { background-repeat:repeat;background-attachment:fixed;background-position:center top;background-size: cover;opacity:1.0;}footer> .texture-overlay { opacity:0.5;background-image: url(http://covetedapp.com/wp-content/themes/massive-dynamic/lib/customizer/assets/images/texture/1.png);}main .content .color-overlay.color-type { display:none }main .content .color-overlay.color-type { background-color: #FFF;}main .content { padding:0px;}main #content { margin-left: auto; margin-right: auto; }footer {width: 100% ; margin-top:0px; }footer .content{width:85%;}#footer-bottom .social-icons span a,#footer-bottom .go-to-top a,#footer-bottom p{color:rgb(52,52,52)}footer.footer-default .footer-widgets {background-color:rgba(255,80,105,0);overflow: hidden;}footer .widget-area {height:373px;}footer hr.footer-separator{height:0px;background-color:rgb(250,92,92)}footer.footer-default .widget-area.classicStyle.border.boxed div[class*="col-"]{height:253px;}footer.footer-default .widget-area.classicStyle.border.full div[class*="col-"]{height :373px;padding : 45px 30px;}footer.footer-default #footer-bottom{background-color:rgb(255,255,255);}#footer-bottom{height:149px;}#footer-bottom .social-icons > span:not(.go-to-top){display:inline-flex;}#footer-bottom .copyright{display:block;}#footer-bottom .logo{opacity:1;}#footer-bottom {display:block;}.sidebar.box .widget > .color-overlay.image-type,.sidebar.box .widget> .bg-image { display:none; }.sidebar.box .widget > .color-overlay.texture-type,.sidebar.box .widget> .texture-overlay{ display:none; }.sidebar.box .widget> .color-overlay.color-type {background-color:#FFF;}.sidebar.box .widget> .bg-image { background-repeat:no-repeat;background-attachment:fixed;background-position:center top;background-size: cover;opacity:1;}.sidebar.box .widget> .texture-overlay { opacity:0.5;background-image: url(http://covetedapp.com/wp-content/themes/massive-dynamic/lib/customizer/assets/images/texture/1.png);}.sidebar > .color-overlay.image-type,.sidebar> .bg-image { display:none; }.sidebar > .color-overlay.texture-type,.sidebar> .texture-overlay{ display:none; }.sidebar> .color-overlay.color-type {background-color:#FFF;}.sidebar> .bg-image { background-repeat:no-repeat;background-attachment:fixed;background-position:center top;background-size: cover;opacity:1;}.sidebar> .texture-overlay { opacity:0.5;background-image: url(http://covetedapp.com/wp-content/themes/massive-dynamic/lib/customizer/assets/images/texture/1.png);}.sidebar.box .widget .color-overlay, .sidebar.box .widget .texture-overlay, .sidebar.box .widget .bg-image{ display:none;}.dark-sidebar .widget-contact-info-content, .dark .widget-contact-info-content{ background:url(http://covetedapp.com/wp-content/themes/massive-dynamic/assets/img/map-dark.png)no-repeat 10px 15px;}.light-sidebar .widget-contact-info-content, .light .widget-contact-info-content{ background:url(http://covetedapp.com/wp-content/themes/massive-dynamic/assets/img/map-light.png)no-repeat 10px 15px;}.layout-container .business { background:rgb(82,82,82);top:0px;height: 36px;}.layout-container .business,.layout-container .business a { color:rgba(255,255,255,1);}header { margin-top: 0 }.box_size{ width:70%}.box_size_container{ width:70%}.widget a, .widget p, .widget span:not(.icon-caret-right)/*:not(.star-rating span)*/{ font-family:Work Sans;}.loop-post-content .post-title:hover{ color:rgba(0,0,0,0.8);;}.woocommerce ul.product_list_widget li span:not(.star-rating span){ font-family:Work Sans;}.notification-center .post .date .day.accent-color, #notification-tabs p.total, #notification-tabs p.total .amount, #notification-tabs .cart_list li .quantity, #notification-tabs .cart_list li .quantity .amount{ color :rgb(181,169,114);}.notification-center span, .notification-center a, .notification-center p, #notification-tabs #result-container .search-title, #notification-tabs #result-container .more-result, #notification-tabs #result-container .item .title, #notification-tabs #search-input, #notification-tabs .cart_list li.empty, .notification-collapse{ font-family :Poppins;}.notification-center .pager .posts, .notification-center #notification-tabs .pager .posts.selected{ display :none; }.notification-center .tabs-container .posts-tab{ opacity : 0 ; }.notification-center .pager .portfolio, .notification-center #notification-tabs .pager .portfolio.selected{ display :none; }.notification-center .tabs-container .protfolio-tab{ opacity : 0 ; }.portfolio .accent-color, .portfolio .accent-color.more-project, .portfolio-carousel .accent-color.like:hover, .portfolio-carousel .buttons .sharing:hover{ color :rgb(250,92,92)}.portfolio-split .accent-color.like:hover, .portfolio-full .accent-color.like:hover{ background-color :rgb(250,92,92);border-color :rgb(250,92,92);color:#fff; }.portfolio .accent-color.more-project:after{ background-color :rgb(250,92,92)}.portfolio .accent-color.more-project:hover{ color :rgba(250,92,92,0.6);}.portfolio .category span { color :rgba(0,0,0,0.7);}.portfolio .buttons .sharing, .portfolio-carousel .buttons .like{ border-color:rgb(0,0,0);color: rgb(0,0,0); }.portfolio-split .buttons .sharing:hover, .portfolio-full .buttons .sharing:hover{ background-color:rgb(0,0,0);color: #fff; }.md-pixflow-slider .btn-container .shortcode-btn a.button{ font-family:Work Sans;}.md-statistic .timer-holder .timer, .md-counter:not(.md-countbox):not(.md-counter-card) .timer, .img-box-fancy .image-box-fancy-title{ font-family:Poppins;letter-spacing:0px;}.process-panel-main-container .sub-title{ font-family:Poppins;font-weight:400;font-style:normal;letter-spacing:0px;}.error404 .item-setting, body:not(.compose-mode) .item-setting{display: none;}header.top-classic .style-none nav > ul > .item_button{color:rgb(0,0,0);}header.top-classic .style-none nav > ul > .item_button:hover{color:rgb(255,255,255);}header.top-classic .style-none nav > ul > .item_button.oval_outline-style a,header.top-classic .style-none nav > ul > .item_button.rectangle_outline-style a{border-color:rgb(255,255,255);}header.top-classic .style-none nav > ul > .item_button.oval-style a,header.top-classic .style-none nav > ul > .item_button.rectangle-style a{background-color:rgb(255,255,255);}h1{color:rgb(0,0,0);font-family:Poppins;font-weight:400;font-style:normal;font-size:70px;line-height:75px;letter-spacing:0px;}h2{color:rgb(0,0,0);font-family:Poppins;font-weight:400;font-style:normal;font-size:60px;line-height:65px;letter-spacing:0px;}h3, h3.wpb_accordion_header,h3.wpb_toggle_header,.woocommerce-loop-product__title{color:rgb(0,0,0);font-family:Poppins;font-weight:400;font-style:normal;font-size:50px;line-height:55px;letter-spacing:0px;}h4{color:rgb(0,0,0);font-family:Poppins;font-weight:400;font-style:normal;font-size:40px;line-height:45px;letter-spacing:0px;}h5{color:rgb(0,0,0);font-family:Poppins;font-weight:400;font-style:normal;font-size:30px;line-height:35px;letter-spacing:0px;}h6{color:rgb(0,0,0);font-family:Poppins;font-weight:400;font-style:;font-size:18px;line-height:30px;letter-spacing:0px;}p{color:rgb(0,0,0);font-family:Work Sans;font-weight:400;font-style:normal;font-size:14px;line-height:14px;letter-spacing:0px;}a{color:rgb(0,0,0);font-family:Work Sans;font-weight:400;font-style:normal;font-size:14px;line-height:14px;letter-spacing:0px;}.layout{padding-top:0px;padding-bottom:0px;width:100%;}main{padding-top:0px;}header .content ul.icons-pack li.icon ,header.top-block .style-style2 .icons-pack .icon.notification-item{display:none;}header { top:22px;}header[class *= "side-" ]{width: 14%;;}header:not(.top-block) .top nav > ul > li .menu-title .icon , header.side-classic .side nav > ul > li > a .menu-title .icon, header.side-classic.standard-mode .style-center nav > ul > li > a .menu-title .icon, .gather-overlay .navigation li a span.icon, header.top-block.header-style1 .navigation > ul > li > a span.icon, header:not(.top-block) .top nav > ul > li .hover-effect .icon {display:none;} header:not(.top-block) .top nav > ul > li .menu-title .title, header.side-classic .side nav > ul > li > a .menu-title .title, header:not(.top-block) .top nav > ul > li .hover-effect .title {display:inline-block;}.activeMenu{ color:rgb(255,255,255) !important;}header a, header .navigation a, header .navigation, .gather-overlay .menu a, header.side-classic div.footer .footer-content .copyright p{ color:rgb(255,255,255);font-family:Poppins;font-weight:400;font-style:normal;font-size:14px;letter-spacing:0px;line-height : 1.5em;}header .icons-pack a{color:rgb(255,255,255)}header .navigation .separator a {background-color:rgba(255,255,255,0.5);;}header .icons-pack .elem-container .title-content{color:rgb(255,255,255);}.top-classic .navigation .menu-separator,.top-logotop .navigation .menu-separator{ background-color:rgb(255,255,255);}.top-classic:not(.header-clone) .style-wireframe .navigation .menu-separator{ background-color:rgb(255,255,255);}header.top-block .icons-pack li .elem-container,header .top .icons-pack .icon span,header.top-block .icons-pack li .title-content .icon,header.top-modern .icons-pack li .title-content .icon,header .icons-pack a{ font-size:18px;}.gather-btn .gather-menu-icon,header .icons-pack a.shopcart .icon-shopcart2,header .icons-pack a.shopcart .icon-shopping-cart{font-size:21px;}header .icons-pack .shopcart-item .number{color:rgb(255,255,255);background-color:rgb(255,255,255);}.layout-container .business{display:none;}header.top-classic:not(.header-clone) .content:not(.style-wireframe) nav > ul > li:hover > a .menu-title , header.top-classic:not(.header-clone) .content:not(.style-wireframe) nav > ul > li:hover > a .menu-title:after{ color:rgb(255,255,255);} .top-classic .style-wireframe .navigation > ul > li:hover .menu-separator{ background-color:rgb(255,255,255);} header.top-classic .icons-pack .icon:hover { color:rgb(255,255,255);}header.top-modern .btn-1b:after { background:rgb(255,255,255);}header.top-modern .btn-1b:active{ background:rgb(255,255,255);}header.top-modern nav > ul> li, header.top-modern .icons-pack li, header.top-modern .first-part{ border-right: 1px solid rgba(255,255,255,0.3);;}header.top-modern .business{ border-bottom: 1px solid rgba(255,255,255,0.3);;}header.top-modern .business, header.top-modern .business a{ color:rgb(255,255,255);}header.side-classic nav > ul > li:hover > a, header.side-classic.standard-mode .icons-holder ul.icons-pack li:hover a, header.side-classic.standard-mode .footer-socials li:hover a, header.side-classic nav > ul > li.has-dropdown:not(.megamenu):hover > a, header.side-classic nav > ul > li:hover > a > .menu-title span, header.side-classic .footer-socials li a .hover, header.side-classic .icons-pack li a .hover, header.side-modern .icons-pack li a span.hover, header.side-modern .nav-modern-button span.hover, header.side-modern .footer-socials span.hover, header.side-classic nav > ul > li.has-dropdown:not(.megamenu) .dropdown a:hover .menu-title span, header.side-classic nav > ul > li > ul li.has-dropdown:not(.megamenu):hover > a .menu-title span{ color:rgb(255,255,255);border-color:rgb(255,255,255);}header.side-classic div.footer ul li.info .footer-content span, header.side-classic .icons-pack li.search .search-form input{ color:rgb(255,255,255);}header.side-classic div.footer ul, header.side-classic div.footer ul li, header.side-classic .icons-holder{ border-color:rgb(255,255,255);}header.side-classic .icons-holder li hr{ background-color:rgb(255,255,255);}header .side .footer .copyright p{ color:rgb(255,255,255);}header .color-overlay, header.side-modern .footer .info .footer-content .copyright, header.side-modern .footer .info .footer-content .footer-socials, header.side-modern .search-form input[type="text"]{background-color: rgba(255,255,255,0);}header:not(.header-clone) > .color-overlay{}.second-header-bg {}header nav.navigation li.megamenu > .dropdown, header nav.navigation li.has-dropdown > .dropdown{ display : table; position: absolute; top:70px;}header nav.navigation li.megamenu > .dropdown > .megamenu-dropdown-overlay, .gather-overlay nav li.megamenu > .dropdown > .megamenu-dropdown-overlay, header nav > ul > li.has-dropdown:not(.megamenu) ul .megamenu-dropdown-overlay{ background-color:rgba(255,255,255,.8);}header nav.navigation > ul > li.megamenu > ul > li > a{ color:rgb(200,200,200);}header[class *= "top-"]:not(.right) nav.navigation li.megamenu > ul.dropdown:not(.side-line), header[class *= "top-"]:not(.right) nav.navigation > ul > li.has-dropdown > ul.dropdown:not(.side-line){border-top:3px solid rgba(63,63,63,1);}header.top nav.navigation > ul > li.has-dropdown:not(.megamenu) .dropdown.side-line, header.top nav.navigation li.megamenu > .dropdown.side-line, .gather-overlay nav.navigation > ul > li.has-dropdown:not(.megamenu) .dropdown.side-line, .gather-overlay nav.navigation li.megamenu > .dropdown.side-line{ border-left: 3px solid rgba(63,63,63,1);}header.top nav.navigation > ul > li.has-dropdown:not(.megamenu) .dropdown.side-line li:after, .gather-overlay nav.navigation > ul > li.has-dropdown:not(.megamenu) .dropdown.side-line li:after{ background-color:rgba(0,0,0,0.3);;}header[class *= "top-"]:not(.right) nav.navigation li.megamenu > .dropdown,header[class *= "top-"]:not(.right) nav.navigation li.has-dropdown > .dropdown{left: 0;}header[class *= "top-"] nav .dropdown a, header[class *= "side-"] nav .dropdown a, .gather-overlay nav .dropdown a{ font-size:13px;}.gather-overlay nav.navigation li.megamenu > .dropdown, .gather-overlay nav.navigation li.has-dropdown > .dropdown{ background-color:rgba(255,255,255,.8);display : table; left: 0; position: absolute; top: 150%; }header.left nav.navigation > ul > li.has-dropdown > .dropdown .megamenu-dropdown-overlay, header.side-modern .side.style-style2 nav > ul > li .megamenu-dropdown-overlay, header.side-modern .side.style-style1 nav > ul .megamenu-dropdown-overlay, header.side-modern .style-style1.side nav ul li{ background-color:rgba(255,255,255,.8);}header.side-modern .style-style1.side nav ul li, header.side-modern .style-style1.side nav.navigation > ul > li.has-dropdown .dropdown{ border-color:rgba(0,0,0,0.3);;color:rgb(0,0,0);}header nav.navigation .dropdown a, header.side-modern nav.navigation a, .gather-overlay nav.navigation .dropdown a{ color:rgb(0,0,0);position: relative !important; width: auto !important;}header .top nav > ul > li > ul li:hover > a .menu-title span, header .top nav > ul > li .dropdown a:hover .menu-title span, .gather-overlay nav > ul > li > ul li:hover > a .menu-title span, .gather-overlay nav > ul > li .dropdown a:hover .menu-title span, header.side-classic nav > ul > li > ul li:hover > a .menu-title span, header.side-classic nav > ul > li .dropdown a:hover .menu-title span, header.side-modern .side.style-style2 nav.navigation ul li a:hover{ color:rgba(63,63,63,1);border-color:rgba(63,63,63,1);}header.side-modern .side.style-style1 nav.navigation ul li:hover{ background-color:rgba(63,63,63,1);}.layout-container> .color-overlay,.layout-container> .texture-overlay,.layout-container > .bg-image { display:none; }.layout-container > .color-overlay.image-type,.layout-container> .bg-image { display:none; }.layout-container > .color-overlay.texture-type,.layout-container> .texture-overlay{ display:none; }.layout-container> .color-overlay.color-type {background-color:#FFF;}.layout-container> .bg-image { background-repeat:no-repeat;background-attachment:fixed;background-position:center top;background-size: cover;opacity:1;}.layout-container> .texture-overlay { opacity:0.5;background-image: url(http://covetedapp.com/wp-content/themes/massive-dynamic/lib/customizer/assets/images/texture/1.png);}footer> .color-overlay,footer> .texture-overlay,footer > .bg-image { display:none; }footer> .color-overlay.color-type { display:none; }footer > .color-overlay.texture-type,footer> .texture-overlay{ display:none; }footer> .bg-image { background-repeat:repeat;background-attachment:fixed;background-position:center top;background-size: cover;opacity:1.0;}footer> .texture-overlay { opacity:0.5;background-image: url(http://covetedapp.com/wp-content/themes/massive-dynamic/lib/customizer/assets/images/texture/1.png);}main .content .color-overlay.color-type { display:none }main .content .color-overlay.color-type { background-color: #FFF;}main .content { padding:0px;}main #content { margin-left: auto; margin-right: auto; }footer {width: 100% ; margin-top:0px; }footer .content{width:85%;}#footer-bottom .social-icons span a,#footer-bottom .go-to-top a,#footer-bottom p{color:rgb(52,52,52)}footer.footer-default .footer-widgets {background-color:rgba(255,80,105,0);overflow: hidden;}footer .widget-area {height:373px;}footer hr.footer-separator{height:0px;background-color:rgb(250,92,92)}footer.footer-default .widget-area.classicStyle.border.boxed div[class*="col-"]{height:253px;}footer.footer-default .widget-area.classicStyle.border.full div[class*="col-"]{height :373px;padding : 45px 30px;}footer.footer-default #footer-bottom{background-color:rgb(255,255,255);}#footer-bottom{height:149px;}#footer-bottom .social-icons > span:not(.go-to-top){display:inline-flex;}#footer-bottom .copyright{display:block;}#footer-bottom .logo{opacity:1;}#footer-bottom {display:block;}.sidebar.box .widget > .color-overlay.image-type,.sidebar.box .widget> .bg-image { display:none; }.sidebar.box .widget > .color-overlay.texture-type,.sidebar.box .widget> .texture-overlay{ display:none; }.sidebar.box .widget> .color-overlay.color-type {background-color:#FFF;}.sidebar.box .widget> .bg-image { background-repeat:no-repeat;background-attachment:fixed;background-position:center top;background-size: cover;opacity:1;}.sidebar.box .widget> .texture-overlay { opacity:0.5;background-image: url(http://covetedapp.com/wp-content/themes/massive-dynamic/lib/customizer/assets/images/texture/1.png);}.sidebar > .color-overlay.image-type,.sidebar> .bg-image { display:none; }.sidebar > .color-overlay.texture-type,.sidebar> .texture-overlay{ display:none; }.sidebar> .color-overlay.color-type {background-color:#FFF;}.sidebar> .bg-image { background-repeat:no-repeat;background-attachment:fixed;background-position:center top;background-size: cover;opacity:1;}.sidebar> .texture-overlay { opacity:0.5;background-image: url(http://covetedapp.com/wp-content/themes/massive-dynamic/lib/customizer/assets/images/texture/1.png);}.sidebar.box .widget .color-overlay, .sidebar.box .widget .texture-overlay, .sidebar.box .widget .bg-image{ display:none;}.dark-sidebar .widget-contact-info-content, .dark .widget-contact-info-content{ background:url(http://covetedapp.com/wp-content/themes/massive-dynamic/assets/img/map-dark.png)no-repeat 10px 15px;}.light-sidebar .widget-contact-info-content, .light .widget-contact-info-content{ background:url(http://covetedapp.com/wp-content/themes/massive-dynamic/assets/img/map-light.png)no-repeat 10px 15px;}.layout-container .business { background:rgb(82,82,82);top:0px;height: 36px;}.layout-container .business,.layout-container .business a { color:rgba(255,255,255,1);}header { margin-top: 0 }.box_size{ width:70%}.box_size_container{ width:70%}.widget a, .widget p, .widget span:not(.icon-caret-right)/*:not(.star-rating span)*/{ font-family:Work Sans;}.loop-post-content .post-title:hover{ color:rgba(0,0,0,0.8);;}.woocommerce ul.product_list_widget li span:not(.star-rating span){ font-family:Work Sans;}.notification-center .post .date .day.accent-color, #notification-tabs p.total, #notification-tabs p.total .amount, #notification-tabs .cart_list li .quantity, #notification-tabs .cart_list li .quantity .amount{ color :rgb(181,169,114);}.notification-center span, .notification-center a, .notification-center p, #notification-tabs #result-container .search-title, #notification-tabs #result-container .more-result, #notification-tabs #result-container .item .title, #notification-tabs #search-input, #notification-tabs .cart_list li.empty, .notification-collapse{ font-family :Poppins;}.notification-center .pager .posts, .notification-center #notification-tabs .pager .posts.selected{ display :none; }.notification-center .tabs-container .posts-tab{ opacity : 0 ; }.notification-center .pager .portfolio, .notification-center #notification-tabs .pager .portfolio.selected{ display :none; }.notification-center .tabs-container .protfolio-tab{ opacity : 0 ; }.portfolio .accent-color, .portfolio .accent-color.more-project, .portfolio-carousel .accent-color.like:hover, .portfolio-carousel .buttons .sharing:hover{ color :rgb(250,92,92)}.portfolio-split .accent-color.like:hover, .portfolio-full .accent-color.like:hover{ background-color :rgb(250,92,92);border-color :rgb(250,92,92);color:#fff; }.portfolio .accent-color.more-project:after{ background-color :rgb(250,92,92)}.portfolio .accent-color.more-project:hover{ color :rgba(250,92,92,0.6);}.portfolio .category span { color :rgba(0,0,0,0.7);}.portfolio .buttons .sharing, .portfolio-carousel .buttons .like{ border-color:rgb(0,0,0);color: rgb(0,0,0); }.portfolio-split .buttons .sharing:hover, .portfolio-full .buttons .sharing:hover{ background-color:rgb(0,0,0);color: #fff; }.md-pixflow-slider .btn-container .shortcode-btn a.button{ font-family:Work Sans;}.md-statistic .timer-holder .timer, .md-counter:not(.md-countbox):not(.md-counter-card) .timer, .img-box-fancy .image-box-fancy-title{ font-family:Poppins;letter-spacing:0px;}.process-panel-main-container .sub-title{ font-family:Poppins;font-weight:400;font-style:normal;letter-spacing:0px;}.error404 .item-setting, body:not(.compose-mode) .item-setting{display: none;}header.top-classic .style-none nav > ul > .item_button{color:rgb(0,0,0);}header.top-classic .style-none nav > ul > .item_button:hover{color:rgb(255,255,255);}header.top-classic .style-none nav > ul > .item_button.oval_outline-style a,header.top-classic .style-none nav > ul > .item_button.rectangle_outline-style a{border-color:rgb(255,255,255);}header.top-classic .style-none nav > ul > .item_button.oval_outline-style:hover a,header.top-classic .style-none nav > ul > .item_button.rectangle_outline-style:hover a{border-color:rgb(0,100,244);background-color:rgb(0,100,244)}header.top-classic .style-none nav > ul > .item_button.oval-style:hover a,header.top-classic .style-none nav > ul > .item_button.rectangle-style:hover a{background-color:rgb(0,100,244)}body.massive-rtl{font-family:Work Sans;}
@media (max-width:1270px){.img-box-slider .slides ,.img-box-slider ul>li, .remove-padding .img-box-slider ul{max-height:800px !important;}.img-box-slider.md-align-center .imgBox-image{background-size:contain !important;}}@media (min-width:1280px) and (max-width:1440px){.img-box-slider ul, .img-box-slider ul>li{  max-height:537px !important;}.erow span{    font-size:32px;}}@media (max-width:1025px){.remove-background{padding-top:60px!important;padding-bottom:40px!important}.remove-padding{padding-bottom:0!important}.img-box-slider ul>li,.remove-padding .img-box-slider ul{height:100%;position:relative;max-height:400px!important}}@media (max-width:800px){.remove-background .row-image{background-image:url(http://demo.massivedynamic.co/startup2/wp-content/uploads/2017/04/Massive-Dynamic-2.jpg)!important}}.modal.in .modal-dialog{ margin-top:127px;}.modal.in .modal-dialog{  margin-top:127px;}.form-container-modern .submit-button{ background-color:rgba(255,255,255,1); border:rgba(250,92,92,1); }.form-container-modern .submit-button:hover{ background-color:rgba(250,92,92,1);}.form-container-modern .submit-button{ background-color:rgba(255,255,255,1); border:rgba(250,92,92,1); }.form-container-modern .submit-button:hover{ background-color:rgba(250,92,92,1);}#footer-bottom .social-icons span a:hover{ opacity:1; color:#FA5C5C !important;}@media (max-width:1280px){body:not(.compose-mode) div.layout header:not(.retina-screen-header) > div.color-overlay{background-color:#ffffff ;}}
</style>
<link rel='stylesheet' id='wpcw-css'  href='http://covetedapp.com/wp-content/plugins/contact-widgets/assets/css/style.min.css?ver=1.0.1' type='text/css' media='all' />
<link rel='stylesheet' id='gem-base-css'  href='http://covetedapp.com/wp-content/plugins/godaddy-email-marketing-sign-up-forms/css/gem.min.css?ver=1.2.0' type='text/css' media='all' />
<link rel='stylesheet' id='ms-main-css'  href='http://covetedapp.com/wp-content/plugins/masterslider/public/assets/css/masterslider.main.css?ver=3.2.2' type='text/css' media='all' />
<link rel='stylesheet' id='ms-custom-css'  href='http://covetedapp.com/wp-content/uploads/masterslider/custom.css?ver=1.2' type='text/css' media='all' />
<link rel='stylesheet' id='A2A_SHARE_SAVE-css'  href='http://covetedapp.com/wp-content/plugins/add-to-any/addtoany.min.css?ver=1.14' type='text/css' media='all' />
<link rel='stylesheet' id='sccss_style-css'  href='http://covetedapp.com?sccss=1&#038;ver=4.9.1' type='text/css' media='all' />
<link rel='stylesheet' id='bootstrap-style-css'  href='http://covetedapp.com/wp-content/themes/massive-dynamic/assets/css/bootstrap.min.css' type='text/css' media='all' />
<script type='text/javascript' src='http://covetedapp.com/wp-includes/js/jquery/jquery.js?ver=1.12.4'></script>
<script type='text/javascript'>
try {}catch(e){console.log("Syntax Error in Custom JS")}
</script>
<script type='text/javascript' src='http://covetedapp.com/wp-includes/js/jquery/jquery-migrate.min.js?ver=1.4.1'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var monsterinsights_frontend = {"js_events_tracking":"true","is_debug_mode":"false","download_extensions":"doc,exe,js,pdf,ppt,tgz,zip,xls","inbound_paths":"","home_url":"http:\/\/covetedapp.com","track_download_as":"event","internal_label":"int","hash_tracking":"false"};
/* ]]> */
</script>
<script type='text/javascript' src='http://covetedapp.com/wp-content/plugins/google-analytics-for-wordpress/assets/js/frontend.min.js?ver=6.2.6'></script>
<script type='text/javascript' src='http://covetedapp.com/wp-content/plugins/add-to-any/addtoany.min.js?ver=1.0'></script>
<script type='text/javascript' src='http://covetedapp.com/wp-content/plugins/revslider/public/assets/js/jquery.themepunch.tools.min.js?ver=5.4.6.3'></script>
<script type='text/javascript' src='http://covetedapp.com/wp-content/plugins/revslider/public/assets/js/jquery.themepunch.revolution.min.js?ver=5.4.6.3'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var wc_add_to_cart_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"http:\/\/covetedapp.com\/?wc-ajax=%%endpoint%%","i18n_view_cart":"View cart","cart_url":"http:\/\/covetedapp.com","is_cart":"","cart_redirect_after_add":"no"};
/* ]]> */
</script>
<script type='text/javascript' src='http://covetedapp.com/wp-content/plugins/woocommerce/assets/js/frontend/add-to-cart.min.js?ver=3.2.4'></script>
<script type='text/javascript' src='http://covetedapp.com/wp-content/plugins/wp-scroll-depth/js/jquery-scrolldepth/jquery.scrolldepth.min.js?ver=4.9.1'></script>
<script type='text/javascript' src='http://covetedapp.com/wp-content/plugins/js_composer/assets/js/vendors/woocommerce-add-to-cart.js?ver=5.4.2'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var pys_fb_pixel_options = {"woo":{"is_product":false,"add_to_cart_enabled":true}};
var pys_events = [{"type":"init","name":"1985016885051972","params":[]},{"type":"track","name":"PageView","params":{"domain":"covetedapp.com"},"delay":0}];
/* ]]> */
</script>
<script type='text/javascript' src='http://covetedapp.com/wp-content/plugins/pixelyoursite/js/public.js?ver=5.0.8'></script>
<script type='text/javascript' src='http://covetedapp.com/wp-content/themes/massive-dynamic/assets/js/jquery.flexslider-min.js'></script>
<link rel='https://api.w.org/' href='http://covetedapp.com/wp-json/' />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://covetedapp.com/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="http://covetedapp.com/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 4.9.1" />
<meta name="generator" content="WooCommerce 3.2.4" />

<script type="text/javascript">
window.a2a_config=window.a2a_config||{};a2a_config.callbacks=[];a2a_config.overlays=[];a2a_config.templates={};
</script>
<script type="text/javascript" src="https://static.addtoany.com/menu/page.js" async="async"></script>
<script type="text/javascript">
(function(h,e,a,t,m,p) {
m=e.createElement(a);m.async=!0;m.src=t;
p=e.getElementsByTagName(a)[0];p.parentNode.insertBefore(m,p);
})(window,document,'script','https://u.heatmap.it/log.js');
</script>
		<script>var ms_grabbing_curosr='http://covetedapp.com/wp-content/plugins/masterslider/public/assets/css/common/grabbing.cur',ms_grab_curosr='http://covetedapp.com/wp-content/plugins/masterslider/public/assets/css/common/grab.cur';</script>
<meta name="generator" content="MasterSlider 3.2.2 - Responsive Touch Image Slider" />
<script>
	jQuery( document ).ready(function(){
		jQuery.scrollDepth({
			elements: [''],
			percentage: true,
			userTiming: true,
			pixelDepth: true,
			nonInteraction: true,
			gtmOverride: false,
	});
});
</script>

		<!-- Facebook Pixel code is added on this page by PixelYourSite FREE v5.0.8 plugin. You can test it with Pixel Helper Chrome Extension. -->

			<noscript><style>.woocommerce-product-gallery{ opacity: 1 !important; }</style></noscript>
			<style type="text/css">.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}</style>
		<meta name="generator" content="Powered by WPBakery Page Builder - drag and drop page builder for WordPress."/>
<!--[if lte IE 9]><link rel="stylesheet" type="text/css" href="http://covetedapp.com/wp-content/plugins/js_composer/assets/css/vc_lte_ie9.min.css" media="screen"><![endif]--><meta name="generator" content="Powered by Slider Revolution 5.4.6.3 - responsive, Mobile-Friendly Slider Plugin for WordPress with comfortable drag and drop interface." />
<link rel="icon" href="http://covetedapp.com/wp-content/uploads/2017/11/FavIcon1-81x81.png" sizes="32x32" />
<link rel="icon" href="http://covetedapp.com/wp-content/uploads/2017/11/FavIcon1-300x300.png" sizes="192x192" />
<link rel="apple-touch-icon-precomposed" href="http://covetedapp.com/wp-content/uploads/2017/11/FavIcon1-180x180.png" />
<meta name="msapplication-TileImage" content="http://covetedapp.com/wp-content/uploads/2017/11/FavIcon1-300x300.png" />
<script type="text/javascript">function setREVStartSize(e){
				try{ var i=jQuery(window).width(),t=9999,r=0,n=0,l=0,f=0,s=0,h=0;					
					if(e.responsiveLevels&&(jQuery.each(e.responsiveLevels,function(e,f){f>i&&(t=r=f,l=e),i>f&&f>r&&(r=f,n=e)}),t>r&&(l=n)),f=e.gridheight[l]||e.gridheight[0]||e.gridheight,s=e.gridwidth[l]||e.gridwidth[0]||e.gridwidth,h=i/s,h=h>1?1:h,f=Math.round(h*f),"fullscreen"==e.sliderLayout){var u=(e.c.width(),jQuery(window).height());if(void 0!=e.fullScreenOffsetContainer){var c=e.fullScreenOffsetContainer.split(",");if (c) jQuery.each(c,function(e,i){u=jQuery(i).length>0?u-jQuery(i).outerHeight(!0):u}),e.fullScreenOffset.split("%").length>1&&void 0!=e.fullScreenOffset&&e.fullScreenOffset.length>0?u-=jQuery(window).height()*parseInt(e.fullScreenOffset,0)/100:void 0!=e.fullScreenOffset&&e.fullScreenOffset.length>0&&(u-=parseInt(e.fullScreenOffset,0))}f=u}else void 0!=e.minHeight&&f<e.minHeight&&(f=e.minHeight);e.c.closest(".rev_slider_wrapper").css({height:f})					
				}catch(d){console.log("Failure at Presize of Slider:"+d)}
			};</script>
<noscript><style type="text/css"> .wpb_animate_when_almost_visible { opacity: 1; }</style></noscript>	<!-- Custom CSS -->
</head>

<body class="error404 _masterslider _msp_version_3.2.2 no-js wpb-js-composer js-comp-ver-5.4.2 vc_responsive" >
        <div id="pageLoadingOverlay" class="light-loading-overlay">
        <h6 class='loading-text'>
            <img src=''><br>
            <div class="preloader-text"></div>
        </h6>
    </div>
<div class="layout-container" id="layoutcontainer">
        <div class="color-overlay color-type"></div>
        <div class="color-overlay texture-type"></div>
        <div class="color-overlay image-type"></div>
        <div class="texture-overlay"></div>
        <div class="bg-image"></div>
    
    <div class="layout">
                <!--End Header-->    <!-- Start of Wrap -->
    <div class="wrap right " style="" >


    <!-- Business Bar  -->
    <div class="business content visible-desktop hidden-tablet business-off" style="width:95%;">
        <div class=" clearfix">
            <div class="info-container">
                <span class="item address">
                    <span class="icon icon-location"></span>
                    <span class="address-content">Your address will show here</span>
                </span>
                <span class="item tel">
                    <span class="icon icon-phone"></span>
                    <span class="tel-content">+12 34 56 78</span>
                </span>
                <span class="item email">
                    <span class="icon icon-Mail"></span>
                    <span class="email-content">email@example.com</span>
                </span>
            </div>
            <div class="social icon">
                                        <span data-social="facebook"><a href="http://www.facebook.com/covetedapp" target="_blank"><span class="icon-facebook2"></span></a></span>
                                            <span data-social="twitter"><a href="http://www.twitter.com/covetedapp" target="_blank"><span class="icon-twitter5"></span></a></span>
                                            <span data-social="instagram"><a href="http://www.instagram.com/covetedapp" target="_blank"><span class="icon-instagram"></span></a></span>
                                </div>
        </div>
    </div>
<!-- header -->
<header style="width: 95%; height:70px;" class="top-classic header-style1 top header-light logo-dark" data-width="95">
    <div class="color-overlay"></div>
    <div class="texture-overlay"></div>
    <div class="bg-image"></div>

    <div class="content top style-slash" style="width:100%;">
        <a class="logo  item-left" style="width: 15.0%;" data-logoStyle="dark"><img class="logo-img" data-home-url="http://covetedapp.com/" data-light-url="http://covetedapp.com/wp-content/uploads/2017/11/NewLogo1.png" data-dark-url="http://covetedapp.com/wp-content/uploads/2017/11/NewLogo.png" src="http://covetedapp.com/wp-content/uploads/2017/11/NewLogo.png"/></a>
                <nav class='navigation hidden-tablet hidden-phone item-right' style='width: 85.0%;'>
                                    </nav>
            
        
        <a class="navigation-button hidden-desktop visible-tablet" href="#">
            <span class="icon-gathermenu"></span>
        </a>

                    
            </div>

</header>
<nav class="navigation-mobile header-light">
    <ul id="menu-coveted" class="menu"><li id="menu-item-mobile8950" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home"><a href="http://covetedapp.com/#Intro"><span class="menu-separator-block"></span><span class='menu-title md-text-mode'><span class="title">INTRO</span></span><span class="menu-separator"></span></a></li><li class="separator" >&nbsp;<a >&nbsp;</a></li><li id="menu-item-mobile8949" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home"><a href="http://covetedapp.com/#WhyUs"><span class="menu-separator-block"></span><span class='menu-title md-text-mode'><span class="title">WHY US</span></span><span class="menu-separator"></span></a></li><li class="separator" >&nbsp;<a >&nbsp;</a></li><li id="menu-item-mobile8951" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home"><a href="http://covetedapp.com/#FirstDates"><span class="menu-separator-block"></span><span class='menu-title md-text-mode'><span class="title">FIRST DATES</span></span><span class="menu-separator"></span></a></li><li class="separator" >&nbsp;<a >&nbsp;</a></li><li id="menu-item-mobile8952" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home"><a href="http://covetedapp.com/#Screenshots"><span class="menu-separator-block"></span><span class='menu-title md-text-mode'><span class="title">SCREENSHOTS</span></span><span class="menu-separator"></span></a></li><li class="separator" >&nbsp;<a >&nbsp;</a></li><li id="menu-item-mobile8953" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home"><a href="http://covetedapp.com/#Spots"><span class="menu-separator-block"></span><span class='menu-title md-text-mode'><span class="title">SPOTS</span></span><span class="menu-separator"></span></a></li><li class="separator" >&nbsp;<a >&nbsp;</a></li><li id="menu-item-mobile8954" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home"><a href="http://covetedapp.com/#Contact"><span class="menu-separator-block"></span><span class='menu-title md-text-mode'><span class="title">CONTACT US</span></span><span class="menu-separator"></span></a></li><li class="separator" >&nbsp;<a >&nbsp;</a></li></ul><div class="search-form">
    <form action="http://covetedapp.com/">
        <fieldset>
            <input type="text" name="s" placeholder="Search..." value="">
            <input type="submit" value="">
        </fieldset>
    </form>
</div></nav>

                <!-- Start of Main -->
                <main class="clearfix  " style="padding-top:0px; width:100%;">
                                    
        
            <!-- Start of Main content -->
            <div id="content" class="content " style="padding: 0% ;" >
                <div class="color-overlay color-type"></div>
                                            <div class="not-found-page">

                            <div class="image"></div>

                            <strong>404</strong>

                            <p>page is not available</p>

                        </div>
                                    </div>
            <!-- End of Main content -->

            
        </main>
        <!-- End of Main -->

        
<footer id="footer-default-id" class="footer-default " data-footer-status="on" data-width="100">
    <div class="color-overlay texture-type"></div>
    <div class="color-overlay image-type"></div>
    <div class="texture-overlay"></div>
    <div class="bg-image"></div>
            <div class="content-holder">

            <hr class="footer-separator">
    <div id="footer-bottom">
        <div class="linear content">
            <div class="logo"><img src="http://covetedapp.com/wp-content/uploads/2017/11/NewLogo.png" /></div><div class="social-icons  footer-spacer"><span data-social="facebook"><a href="http://www.facebook.com/covetedapp" target="_blank"><span class="icon-facebook2"></span></a></span><span data-social="twitter"><a href="http://www.twitter.com/covetedapp" target="_blank"><span class="icon-twitter5"></span></a></span><span data-social="instagram"><a href="http://www.instagram.com/covetedapp" target="_blank"><span class="icon-instagram"></span></a></span></div><div class="copyright footer-spacer"><p>Copyright © 2017 Coveted</p></div>        </div>
    </div>
    </footer>


    </div>
    <!-- End of Wrap -->

    <div class="clearfix"></div>
<!--end of layout element-->
</div>
<!-- end of layout container -->
</div>

<!-- Go to top button -->

    <div class="go-to-top dark md-hidden"></div>
    <!-- Theme Hook -->


<noscript><img height='1' width='1' style='display: none;' src='https://www.facebook.com/tr?id=1985016885051972&ev=PageView&noscript=1&cd[domain]=covetedapp.com' alt='facebook_pixel'></noscript>
		<script type="text/javascript">
		/* <![CDATA[ */
		var pys_edd_ajax_events = [];
		/* ]]> */
		</script>

		<link rel='stylesheet' id='vc_google_text_fonts-css'  href='//fonts.googleapis.com/css?family=Poppins%3A400%2C700%7CWork+Sans%3A400&#038;ver=4.9.1' type='text/css' media='all' />
<script type='text/javascript'>
/* <![CDATA[ */
var ajax_var = {"url":"http:\/\/covetedapp.com\/wp-admin\/admin-ajax.php","nonce":"4064726398","uniqueSettings":"[\"site_width\",\"site_top\",\"site_bg\",\"site_bg_type\",\"site_bg_color_type\",\"site_bg_solid_color\",\"site_bg_gradient_orientation\",\"site_bg_gradient_color1\",\"site_bg_gradient_color2\",\"site_bg_image_image\",\"site_bg_image_repeat\",\"site_bg_image_attach\",\"site_bg_image_position\",\"site_bg_image_size\",\"site_bg_image_opacity\",\"site_bg_image_overlay\",\"site_bg_image_overlay_type\",\"site_bg_image_solid_overlay\",\"site_bg_overlay_gradient_orientation\",\"site_bg_overlay_gradient_color1\",\"site_bg_overlay_gradient_color2\",\"site_bg_texture\",\"site_bg_texture_opacity\",\"site_bg_texture_overlay\",\"site_bg_texture_solid_overlay\",\"header_position\",\"header_top_position\",\"header_theme\",\"header_side_theme\",\"logotop_logoSpace\",\"classic_style\",\"block_style\",\"gather_style\",\"header_side_align\",\"header_side_footer\",\"header_styles\",\"show_up_after\",\"show_up_style\",\"header_top_width\",\"header-top-height\",\"header-side-width\",\"header-content\",\"menu_item_style\",\"header_items_order\",\"nav_color\",\"nav_hover_color\",\"header_bg_color_type\",\"header_bg_solid_color\",\"header_bg_gradient_orientation\",\"header_bg_gradient_color1\",\"header_bg_gradient_color2\",\"logo_style\",\"header_border_enable\",\"nav_color_second\",\"nav_hover_color_second\",\"header_bg_color_type_second\",\"header_bg_solid_color_second\",\"header_bg_gradient_second_orientation\",\"header_bg_gradient_second_color1\",\"header_bg_gradient_second_color2\",\"logo_style_second\",\"popup_menu\",\"popup_menu_color\",\"overlay_bg\",\"header_side_image_image\",\"header_side_image_repeat\",\"header_side_image_position\",\"header_side_image_size\",\"menu_button_style\",\"button_bg_color\",\"button_text_color\",\"button_hover_text_color\",\"button_hover_bg_color\",\"dropdown_bg_solid_color\",\"dropdown_heading_solid_color\",\"dropdown_fg_solid_color\",\"dropdown_fg_hover_color\",\"businessBar_enable\",\"businessBar_style\",\"businessBar_social\",\"businessBar_content_color\",\"businessBar_bg_color\",\"businessBar_address\",\"businessBar_tel\",\"businessBar_email\",\"nav_name\",\"nav_size\",\"nav_weight\",\"nav_letterSpace\",\"nav_style\",\"main-width\",\"mainC-width\",\"main-top\",\"mainC-padding\",\"main_bg\",\"main_bg_color_type\",\"main_bg_solid_color\",\"main_bg_gradient_orientation\",\"main_bg_gradient_color1\",\"main_bg_gradient_color2\",\"footer_widgets_styles\",\"footer_widget_area_height\",\"footer_bottom_area_height\",\"footer-width\",\"footerC-width\",\"footer-marginT\",\"footer-marginB\",\"footer_widgets_order\",\"footer_widget_area_columns_status\",\"footer_widget_area_columns\",\"footer_bottom_items_layout\",\"footer_copyright_text\",\"footer_switcher\",\"footer_logo\",\"footer_copyright\",\"footer_social\",\"footer_logo_skin\",\"footer_logo_opacity\",\"footer_widget_area_skin\",\"footer_parallax\",\"footer_widget_area_bg_color_rgba\",\"copyright_separator\",\"copyright_color\",\"footer_bottom_area_bg_color_rgba\",\"footer_bg\",\"footer_bg_type\",\"footer_bg_image_image\",\"footer_bg_image_repeat\",\"footer_bg_image_attach\",\"footer_bg_image_position\",\"footer_bg_image_size\",\"footer_bg_image_opacity\",\"footer_bg_image_overlay\",\"footer_bg_image_overlay_type\",\"footer_bg_image_solid_overlay\",\"footer_bg_overlay_gradient_orientation\",\"footer_bg_overlay_gradient_color1\",\"footer_bg_overlay_gradient_color2\",\"footer_bg_texture\",\"footer_bg_texture_opacity\",\"footer_bg_texture_overlay\",\"footer_bg_texture_solid_overlay\",\"go_to_top_status\",\"footer_section_gototop_skin\",\"go_to_top_show\",\"sidebar-switch\",\"sidebar-position\",\"sidebar-width\",\"sidebar-skin\",\"sidebar-style\",\"sidebar-align\",\"sidebar-shadow-color\",\"page_sidebar_bg\",\"page_sidebar_bg_type\",\"page_sidebar_bg_color_type\",\"page_sidebar_bg_solid_color\",\"page_sidebar_bg_gradient_orientation\",\"page_sidebar_bg_gradient_color1\",\"page_sidebar_bg_gradient_color2\",\"page_sidebar_bg_image_image\",\"page_sidebar_bg_image_repeat\",\"page_sidebar_bg_image_attach\",\"page_sidebar_bg_image_position\",\"page_sidebar_bg_image_size\",\"page_sidebar_bg_image_opacity\",\"page_sidebar_bg_image_overlay\",\"page_sidebar_bg_image_overlay_type\",\"page_sidebar_bg_image_solid_overlay\",\"page_sidebar_bg_overlay_gradient_orientation\",\"page_sidebar_bg_overlay_gradient_color1\",\"page_sidebar_bg_overlay_gradient_color2\",\"page_sidebar_bg_texture\",\"page_sidebar_bg_texture_opacity\",\"page_sidebar_bg_texture_overlay\",\"page_sidebar_bg_texture_solid_overlay\",\"sidebar-switch-single\",\"sidebar-position-single\",\"sidebar-width-single\",\"sidebar-skin-single\",\"sidebar-style-single\",\"sidebar-align-single\",\"sidebar-shadow-color-single\",\"single_sidebar_bg\",\"single_sidebar_bg_type\",\"single_sidebar_bg_color_type\",\"single_sidebar_bg_solid_color\",\"single_sidebar_bg_gradient_orientation\",\"single_sidebar_bg_gradient_color1\",\"single_sidebar_bg_gradient_color2\",\"single_sidebar_bg_image_image\",\"single_sidebar_bg_image_repeat\",\"single_sidebar_bg_image_attach\",\"single_sidebar_bg_image_position\",\"single_sidebar_bg_image_size\",\"single_sidebar_bg_image_opacity\",\"single_sidebar_bg_image_overlay\",\"single_sidebar_bg_image_overlay_type\",\"single_sidebar_bg_image_solid_overlay\",\"single_sidebar_bg_overlay_gradient_orientation\",\"single_sidebar_bg_overlay_gradient_color1\",\"single_sidebar_bg_overlay_gradient_color2\",\"single_sidebar_bg_texture\",\"single_sidebar_bg_texture_opacity\",\"single_sidebar_bg_texture_overlay\",\"single_sidebar_bg_texture_solid_overlay\",\"sidebar-switch-shop\",\"sidebar-position-shop\",\"sidebar-width-shop\",\"sidebar-skin-shop\",\"sidebar-style-shop\",\"sidebar-align-shop\",\"sidebar-shadow-color-shop\"]"};
/* ]]> */
</script>
<script type='text/javascript' src='http://covetedapp.com/wp-content/themes/massive-dynamic/lib/assets/script/unique-setting.min.js?ver=1.0'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var ajax_var = {"url":"http:\/\/covetedapp.com\/wp-admin\/admin-ajax.php","nonce":"4064726398"};
/* ]]> */
</script>
<script type='text/javascript' src='http://covetedapp.com/wp-content/themes/massive-dynamic/lib/assets/script/post-like.min.js'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var wpcf7 = {"apiSettings":{"root":"http:\/\/covetedapp.com\/wp-json\/contact-form-7\/v1","namespace":"contact-form-7\/v1"},"recaptcha":{"messages":{"empty":"Please verify that you are not a robot."}},"cached":"1"};
/* ]]> */
</script>
<script type='text/javascript' src='http://covetedapp.com/wp-content/plugins/contact-form-7/includes/js/scripts.js?ver=4.9.1'></script>
<script type='text/javascript' src='http://covetedapp.com/wp-content/plugins/go_pricing/assets/js/go_pricing_scripts.js?ver=3.3.8'></script>
<script type='text/javascript' src='http://covetedapp.com/wp-content/plugins/woocommerce/assets/js/jquery-blockui/jquery.blockUI.min.js?ver=2.70'></script>
<script type='text/javascript' src='http://covetedapp.com/wp-content/plugins/woocommerce/assets/js/js-cookie/js.cookie.min.js?ver=2.1.4'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var woocommerce_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"http:\/\/covetedapp.com\/?wc-ajax=%%endpoint%%"};
/* ]]> */
</script>
<script type='text/javascript' src='http://covetedapp.com/wp-content/plugins/woocommerce/assets/js/frontend/woocommerce.min.js?ver=3.2.4'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var wc_cart_fragments_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"http:\/\/covetedapp.com\/?wc-ajax=%%endpoint%%","fragment_name":"wc_fragments_34827ec3a6ff8e596797cb6cd6c17fbf"};
/* ]]> */
</script>
<script type='text/javascript' src='http://covetedapp.com/wp-content/plugins/woocommerce/assets/js/frontend/cart-fragments.min.js?ver=3.2.4'></script>
<script type='text/javascript' src='http://covetedapp.com/wp-content/themes/massive-dynamic/assets/js/plugins.min.js'></script>
<script type='text/javascript' src='http://covetedapp.com/wp-content/themes/massive-dynamic/lib/assets/script/jquery.nicescroll.min.js'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var ajax_var = {"url":"http:\/\/covetedapp.com\/wp-admin\/admin-ajax.php","nonce":"4064726398"};
var themeOptionValues = {"site_bg_image_attach":"fixed","headerBgColorType":"solid","navColor":"rgb(255,255,255)","navHoverColor":"rgb(255,255,255)","navColorSecond":"rgb(35,35,35)","navHoverColorSecond":"rgb(250,92,92)","headerBgGradientColor1":"rgba(255,255,255,1)","headerBgGradientColor2":"rgba(255,255,255,.5)","headerBgGradientOrientation":"vertical","headerBgColorTypeSecond":"solid","headerBgGradientSecondColor1":"rgba(255,255,255,1)","headerBgGradientSecondColor2":"rgba(255,255,255,.5)","headerBgGradientSecondOrientation":"vertical","headerBgSolidColorSecond":"rgb(255,255,255)","headerBgSolidColor":"rgba(255,255,255,0)","businessBarEnable":"","sidebar_style":"none","page_sidebar_bg_image_position":"center-top","sidebar_style_shop":"none","shop_sidebar_bg_image_position":"center-top","sidebar_style_single":"none","single_sidebar_bg_image_position":"center-top","sidebar_style_blog":"none","blog_sidebar_bg_image_position":"center-top","showUpAfter":"800","showUpStyle":"fade_in","siteTop":"0","footerWidgetAreaSkin":"dark","headerTopWidth":"95","layoutWidth":"100","lightLogo":"http:\/\/covetedapp.com\/wp-content\/uploads\/2017\/11\/NewLogo1.png","darkLogo":"http:\/\/covetedapp.com\/wp-content\/uploads\/2017\/11\/NewLogo.png","logoStyle":"dark","logoStyleSecond":"dark","activeNotificationTab":"posts","goToTopShow":"800","loadingType":"light","leaveMsg":"You are about to leave this page and you haven't saved changes yet, would you like to save changes before leaving?","unsaved":"Unsaved Changes!","save_leave":"Save & Leave","mailchimpNotInstalled":"MailChimp for Wordpress is not installed.","search":"Search...","payment_methods":"PAYMENT METHOD","loadingText":""};
/* ]]> */
</script>
<script type='text/javascript' src='http://covetedapp.com/wp-content/themes/massive-dynamic/assets/js/custom.min.js?ver=5.3'></script>
<script type='text/javascript' src='http://covetedapp.com/wp-content/uploads/md_cache/.js?ver=5.3'></script>
<script type='text/javascript' src='http://covetedapp.com/wp-content/themes/massive-dynamic/assets/js/smooth_scroll.min.js'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var GEM = {"thankyou":"Thank you for signing up!","thankyou_suppressed":"Thank you for signing up! Please check your email to confirm your subscription.","oops":"Oops! There was a problem. Please try again.","email":"Please enter a valid email address.","required":"%s is a required field."};
/* ]]> */
</script>
<script type='text/javascript' src='http://covetedapp.com/wp-content/plugins/godaddy-email-marketing-sign-up-forms/js/gem.min.js?ver=1.2.0'></script>
<script type='text/javascript' src='http://covetedapp.com/wp-includes/js/wp-embed.min.js?ver=4.9.1'></script>

<script type="text/javascript" src="https://cdn.ywxi.net/js/1.js" async></script></body>
</html>